//
//  BlueTF.swift
//  studen-ios
//
//  Created by Andreas on 14.03.2022.
//

import UIKit

class BlueTF: UITextField {
}
