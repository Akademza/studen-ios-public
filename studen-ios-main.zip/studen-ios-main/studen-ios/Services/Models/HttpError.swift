//
//  HttpError.swift
//  studen-ios
//
//  Created by Andreas on 16.03.2022.
//

import Foundation

struct HttpError: Decodable {
    let message: String
}
