//
//  ContactUsVC.swift
//  studen-ios
//
//  Created by Andreas on 15.03.2022.
//

import UIKit

class ContactUsVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction private func backTapped() {
        dismiss(animated: true, completion: nil)
    }
}
